package com.example.dvalert

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class DvCheckWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val connection = (URL(OFFICIAL_PAGE).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 20000
                readTimeout = 20000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 DVAlertAndroid/1.1")
            }
            val html = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val page = html.lowercase()
            val hasDv2028 = page.contains("dv-2028") || page.contains("dv 2028")
            val hasRegistrationContext =
                page.contains("registration") ||
                page.contains("entry period") ||
                page.contains("online entry")
            val hasDateOrStatusContext =
                page.contains("begin") ||
                page.contains("open") ||
                page.contains("through") ||
                page.contains("start date")

            val signal = hasDv2028 && hasRegistrationContext && hasDateOrStatusContext
            val prefs = applicationContext.getSharedPreferences("dv_alert", Context.MODE_PRIVATE)
            val alreadyNotified = prefs.getBoolean("dv2028_notified", false)

            if (signal && !alreadyNotified && notificationsAllowed()) {
                val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Проверь объявление DV-2028")
                    .setContentText("На официальной странице найдено упоминание регистрации DV-2028.")
                    .setStyle(NotificationCompat.BigTextStyle().bigText(
                        "На официальной странице Госдепартамента найдено упоминание DV-2028 и регистрации. Открой официальный сайт и самостоятельно проверь даты и инструкции."
                    ))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(applicationContext).notify(2028, notification)
                prefs.edit().putBoolean("dv2028_notified", true).apply()
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun notificationsAllowed(): Boolean {
        return Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                applicationContext, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        const val CHANNEL_ID = "dv_lottery_alerts"
        private const val OFFICIAL_PAGE =
            "https://travel.state.gov/content/travel/en/US-visas/immigrate/diversity-visa-program-entry.html"

        fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Уведомления DV Lottery",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Объявления о регистрации Diversity Visa"
                }
                context.getSystemService(NotificationManager::class.java)
                    .createNotificationChannel(channel)
            }
        }
    }
}
