package com.example.dvalert

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DvCheckWorker.createNotificationChannel(this)
        requestNotificationPermission()
        scheduleMonitor()

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "DV Alert"
            textSize = 28f
        })
        layout.addView(TextView(this).apply {
            text = "Следит за официальными объявлениями Госдепартамента США о Diversity Visa. Проверка выполняется в фоне примерно каждые 12 часов при наличии интернета."
            textSize = 16f
            setPadding(0, pad, 0, pad)
        })
        layout.addView(TextView(this).apply {
            text = "Уведомление — сигнал проверить официальный сайт, а не гарантия открытия регистрации. Приложение не подаёт заявку и не собирает личные данные."
            textSize = 14f
            setPadding(0, 0, 0, pad)
        })
        layout.addView(Button(this).apply {
            text = "Открыть официальный сайт DV"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dvprogram.state.gov/")))
            }
        })
        layout.addView(Button(this).apply {
            text = "Проверить сейчас"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity)
                    .enqueue(OneTimeWorkRequestBuilder<DvCheckWorker>().build())
            }
        })
        setContentView(layout)
    }

    private fun scheduleMonitor() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<DvCheckWorker>(12, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "dv2028_monitor",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001
            )
        }
    }
}
